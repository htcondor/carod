#!/bin/sh

echo "This is the output file" > output
echo "This is output file 2" > output2
echo "this is output file 3" > output3

exit 0
